#include<iostream>

using namespace std;

class uppertriangle
{
  public:
  int *array;
  uppertriangle(int size)
  {
      array = new int[size];
  }
  void store(int i , int j  , int val)
  {
      if(i<=j)
      {
          int k = i*(i-1)/2 + j;
          array[k] = val;

      }
      else if(i>=j && val!=0)
      {
          ;
      }
      else
      ;

  }
  void retreive(int i , int j)
  {
      for(int i = 0;i<size;i++)
      {
          for(int j=0;j<size;j++)
          {
               if(i<=j)
                    {
                        int k = i*(i-1)/2 + j;
                        cout<<array[k]<<endl;
                    }
                else
                cout<<0<<endl;
          }
      }

  }
};
int main()
{
    int n;
    cout<<"ENTER THE SIZE OF ARRAY"<<endl;
    cin>>n;
    cout<<endl;
    cout<<"ELEMENTS OF THE UPPER TRIANGLE ARE"<<endl;
    //cout<<"ENTER THE NO OF COLS"<<endl;
    //cin>>cols;

    uppertriangle *u1 = new uppertriangle(n*(n+1))/2);
    u1->store(0,0,1);
    u1->store(0,1,2);
    u1->store(0,2,3);
    u1->store(0,3,4);
    u1->store(2,2,5);

    u1->retreive(0,0);
    u1->retreive(0,1);
    u1->retreive(0,2);
    u1->retreive(0,3);
    u1->retreive(2,2);


}