/*
 PROGRAMME FOR DELIMITER MATCHING
*/
#include<string>
#include<iostream>
#define MAX 50

using namespace std;
 class stack
{
    public:
    int tos;
    //bool are_balanced(string s);
    bool push(char ch);
    char pop();
    bool is_empty();
    char array[MAX];
    char top();
    stack()
    {
        tos = -1;
    }
};
bool stack :: push(char ch)
{
    if(tos<MAX-1)
    {
        array[++tos] = ch;
        return true;
    }
    else
    cout<<"STACK OVERFLOW"<<endl;
    return 0;
}
char stack :: pop()
{
    if(!is_empty())
    {
      char temp =  array[tos--];
      return temp;
    }
    else
    return '!';

}
bool stack :: is_empty()
{
   return(tos<0);
}
bool are_pair(char opening, char closing)
{
    if(opening =='(' && closing ==')') return true;
    if(opening =='[' && closing ==']') return true;
    if(opening =='{' && closing =='}') return true;
    else return false;
}
char stack :: top()
{
    return array[tos--];
}
bool are_balanced(string s)
{
    stack stk;
    for(int i=0;i<s.length();i++)
    {
        if(s[i] == '(' || s[i] == '{' || s[i] =='[')
        {
            stk.push(s[i]);
        }
        else if(s[i] == ')' || s[i] == '}' || s[i] == ']')
        {
            if(are_pair(stk.array[stk.tos],s[i]) && !stk.is_empty())
            {
                stk.pop();
            }
        }

    }
    return stk.is_empty()?true:false;
}

int main()
{
    string stk1 = "{a+b*[c]+m/}*(){)()()(){[][]";

    if(are_balanced(stk1)) cout<<"CORRECT";
    else
    cout<<"incorrect";
    return 0;
}