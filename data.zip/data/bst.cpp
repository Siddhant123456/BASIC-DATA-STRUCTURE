#include<iostream>
using namespace std;

class BSTNODE
{
    public:
    int key;
    BSTNODE *left;
    BSTNODE *right;
    BSTNODE()
    {
        left = NULL;
        right = NULL;
    }
};
class BST
{
    public:
    BSTNODE *root;
    BST()
    {
        root = NULL;
    }



    void insert(int el)
    {

        BSTNODE *N = new BSTNODE;

        if(root==NULL)
        {
            root = N;

        }

        BSTNODE *temp = root;
        while(1)
        {
            if(el<temp->key)
            {
                if(temp->left == NULL)
                {
                    temp->left = N;

                    break;
                }
                else
                {
                    temp = temp->left;
                }
            }
            else
            {
                if(temp->right == NULL)
                {
                    temp->right = N;

                    break;
                }
                else
                {
                    temp = temp->right;
                }
            }
        }
            N->left = NULL;
            N->right = NULL;
            N->key = el;
    }
    void inorder(BSTNODE *temp3)  //INORDER TRAVERSAL (LVR)
    {

        if(temp3!=NULL)
        {
            inorder(temp3->left);
            cout<<temp3->key<<endl;
            inorder(temp3->right);
        }
    }
};

int main()
{
    BST b1;

    b1.insert(2);
     b1.insert(6);
     b1.insert(10);
     b1.insert(5);
     b1.insert(1);
   // b1.inorder(b1.root);
}