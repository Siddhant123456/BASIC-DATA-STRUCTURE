#include<iostream>
using namespace std;


int factorial(int n)
{
    if(n==1)
    {
        return 1;
    }
    else
    {
        return n*factorial(n-1);
    }
}

int main()
{
    int no;
    cout<<"Enter the element whose factorial you want to find"<<endl;
    cin>>no;
    cout<<"Factorial of "<<no<<" is ";
    cout<<factorial(no);
}

