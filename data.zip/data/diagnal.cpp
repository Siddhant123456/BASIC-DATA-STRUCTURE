#include<iostream>
using namespace std;
class diagonal_matrix
{
    public:
    int *array;
    diagonal_matrix(int size)
    {
        array = new int[size];
    }
int store(int i , int j , int val)
{
    // cout<<"ENTER THE ELEMENTS OF THE ARRAY"<<endl;
    // int c=0;
    if(i==j)
    {
        //int k = i;
        array[i] = val;
        return 1;
    }
    else if(i!=j && val!=0)
    {
        return 0;
    }
    else if(i!=j && val ==0)
    {
        return 0;
    }
}
 int retrieve(int i , int j)
 {
     for(int i  =0;i<4;i++)
     {
         for(int j=0;j<4;j++)
         {
              if(i==j)
            {
                //int k = i;
                cout<<array[i]<<"  ";
                return 0;
            }
            else
            {
                cout<<"0"<<"  ";
                return 0;
            }



         }
         cout<<endl;
     }


    }



};
int main()
{
    diagonal_matrix *d1 = new diagonal_matrix(4);
    d1->store(0,0,2);
    d1->store(1,1,2);
    d1->store(2,2,3);
    d1->store(3,3,4);


    d1->retrieve(1,1);
    d1->retrieve(2,2);
    d1->retrieve(3,3);
    d1->retrieve(0,0);
}