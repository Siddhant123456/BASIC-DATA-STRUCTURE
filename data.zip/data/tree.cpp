#include<iostream>
using namespace std;

class BSTNODE
{
    public:
    int key;
    BSTNODE *left;
    BSTNODE *right;

    BSTNODE()
    {
        left = NULL;
        right = NULL;
    }
};
class BST
{

    public:
    BSTNODE *root;

    BST()
    {
        root = NULL;
    }
    void insert()
    {
        int el;
        cout<<"ENTER THE NUMBER TO BE ADDED TO THE TREE"<<endl;
        cin>>el;
        BSTNODE *B1 = new BSTNODE;
        BSTNODE *temp = root;
        BSTNODE *temp1 = root;
        if(root==NULL) //tree is empty
        {
            root = B1;
        }
        else
        {
            if(el>root->key)
            {
                while(temp1->right!=NULL || el<temp1->key)
                {
                    temp1 = temp1->right;
                }
                if(el>temp1->key)
                {
                    temp1->right = B1;
                }
                else
                {
                    temp1->left = B1;
                }
            }

            else if(el<root->key)
            {
                while(temp->left!=NULL || el>temp->key)
                {
                    temp = temp->left;
                }
                if(el>temp->key)
                {
                   temp->right = B1;
                }
                else
                {
                   temp->left = B1;
                }
            }
        }
                B1->key = el;
                B1->left = NULL;
                B1->right = NULL;

    }




    void inorder(BSTNODE *temp3)  //INORDER TRAVERSAL (LVR)
    {

        if(temp3!=NULL)
        {
            inorder(temp3->left);
            cout<<temp3->key<<endl;
            inorder(temp3->right);
        }
    }
    void preorder(BSTNODE *temp4) //PREORDER TRAVERSAL(VLR)
    {
        if(temp4!=NULL)
        {
            cout<<temp4->key<<endl;
            preorder(temp4->left);
            preorder(temp4->right);
        }
    }
    void postorder(BSTNODE *temp5) //POSTORDER TRAVERSAL(LRV)
    {
        if(temp5!=NULL)
        {
            postorder(temp5->left);
            postorder(temp5->right);
            cout<<temp5->key<<endl;
        }
    }
    void search()
    {
        int no;
        cout<<"ENTER THE NUMBER YOU WANT TO SEARCH"<<endl;
        cin>>no;
        bool found = false;
        BSTNODE *temp5 = root;
        while(temp5!=NULL)
        {
            if(no==temp5->key)
            {
                cout<<"NUMBER FOUND"<<endl;
                found = true;
                break;
            }
            else if(no>temp5->key)
            {
                temp5 = temp5->right;
            }
            else
            {
                temp5 = temp5->left;
            }
        }
        if(!found)
        cout<<"NUMBER NOT FOUND"<<endl;
    }
    int delete_copying()
    {
        int del_key;
        cout<<"Enter the key you want to delete"<<endl;
        cin>>del_key;
        BSTNODE *temp8 = root;
        BSTNODE *temp9 = root;
        bool isFound = false;
        while(isFound)
        {
            if(del_key==temp8->key)
            {
                temp8 = temp8->left;
                while(temp8->right!=NULL)
                {
                    temp8 = temp8->right;
                }

                int temp_key = temp8->key;
                root->key = temp_key;
                if(temp8->left==NULL)
                {
                    temp8->left->right = NULL;
                }
                else
                {
                    temp8->left =
                }
            }


        }

    }

};

int main()
{
    BST L1;
    int c = 0;
    while(c!=4)
    {
        cout<<"1.INSERT"<<endl;
        cout<<"2.SEARCH"<<endl;
        cout<<"3.DISPLAY"<<endl;
        cout<<"4.EXIT"<<endl;
        cout<<"ENTER YOUR CHOICE"<<endl;

        cin>>c;

        switch(c)
        {
            case 1:
                    L1.insert();
                    break;
            case 2:
                    L1.search();
                    break;
            case 3:
                    int choice;
                    cout<<"WHICH TRAVERSAL YOU WANT TO DO"<<endl;
                    cout<<"1. PREORDER"<<endl;
                    cout<<"2. POSTORDER"<<endl;
                    cout<<"3. INORDER"<<endl;
                    cin>>choice;
                    cout<<"THE ELEMENTS OF THE TREE ARE"<<endl;
                    switch(choice)
                    {
                        case 1:
                                L1.preorder(L1.root);
                                break;
                        case 2:
                                L1.postorder(L1.root);
                                break;
                        case 3:
                                L1.inorder(L1.root);
                                break;
                        default:
                                cout<<"YOU ENTERED A WRONG CHOICE"<<endl;
                    }

                    break;
            case 4:
                    break;

            default:
                    cout<<"YOU ENTERED A WRONG CHOICE"<<endl;
        }
    }




    return 0;
}