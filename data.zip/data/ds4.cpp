// ADD AT HEAD
// DISPLAY
// SEARCH
// ADD AT Nth POSITION
// DELETE FROM Nth POSITION

#include<iostream>
#include<string>
using namespace std;
class SLLNODE
{
public:
int info;
SLLNODE *next;
SLLNODE()
{
next = NULL;
info = 0;
}
};
class SLL
{
public:
SLLNODE *head;
SLLNODE *tail;
SLL()
{
head = NULL;
tail = NULL;
}

void add_at_head()
{
int el;
cout<<"ENTER THE NUMBER TO ADD AT HEAD"<<endl;
cin>>el;
SLLNODE *N2 = new SLLNODE();
N2->info = el;
N2->next = NULL;
if(head==NULL)
{
head = N2;
tail = N2;
}
else
{
SLLNODE *temp = head;
head = N2;
N2->next = temp;
}

}
void display()
{

SLLNODE *temp1;
temp1 = head;
cout<<"-------------------------------\n";
while(temp1!=NULL)
{
cout<<temp1->info;
cout<<" | ";
temp1 = temp1->next;

}
cout<<"\n-------------------------------\n";

}
bool search()
{
int z = 0;
cout<<"ENTER THE NUMBER YOU WANT TO SEARCH"<<endl;
cin>>z;
SLLNODE *temp2;
temp2 = head;
while(temp2!=NULL)
{
if(temp2->info == z)
{
cout<<z<<" "<<"IS THERE IN THE LINKED LIST"<<" "<<endl;
return true;
}
else
temp2 = temp2->next;
}
cout<<z<<" "<<"IS NOT THERE IN THE LINKED LIST"<<" "<<endl;
return false;

}
void add_at_tail()
{
int y = 0;
cout<<"ENTER THE NUMBER YOU WANT TO ADD AT TAIL"<<endl;
cin>>y;
if(head==NULL) // list is empty
{
SLLNODE *N5 = new SLLNODE();
N5->next = NULL;
head = N5;
tail = N5;
N5->info = y;
}
else
{

SLLNODE *N4 = new SLLNODE();
N4->info = y;
N4->next = NULL;


//tempo->next = N4;
tail->next = N4;


tail = N4;



}
}
void add_after_nth_position()
{
int num1 = 0;
int num2 = 0;
cout<<"ENTER THE NUMBER YOU WANT TO ADD"<<endl;
cin>>num1;
cout<<"ENTER THE POSITION YOU WANT TO ADD THE NUMBER"<<endl;
cin>>num2;
if(head==NULL)
{
cout<<"THERE IS NO ELEMENT IN THE LIST"<<endl;
cout<<"ERROR"<<endl;
}
else
{


SLLNODE *temp3 = head;
SLLNODE *temp4 = temp3;
SLLNODE *N3 = new SLLNODE();
N3->info = num1;
N3->next = NULL;
for(int i=1;i<num2;i++)
{
temp3 = temp3->next;
}
temp4 = temp3->next;
temp3->next = N3;
N3->next = temp4;
}

}
void add_before_nth_position()
{
int num3;
int num4;
cout<<"ENTER THE NUMBER YOU WANT TO ADD"<<endl;
cin>>num3;
cout<<"ENTER THE POSITION YOU WANT TO ADD THE NUMBER"<<endl;
cin>>num4;
if(head == NULL)
{
cout<<"THERE IS NO ELEMENT IN THE LIST"<<endl;
cout<<"ERROR"<<endl;
}

else
{
SLLNODE *N6 = new SLLNODE();
num4 = num4-1;
SLLNODE *temp5 = head;
SLLNODE *temp6 = temp5;
//SLLNODE *N3 = new SLLNODE();
N6->info = num3;
N6->next = NULL;
for(int i=1;i<num4;i++)
{
temp5 = temp5->next;
}
temp6 = temp5->next;
temp5->next = N6;
N6->next = temp6;
}
}
int del()
{
int posd = 0;
cout<<"ENTER THE POSITION FROM WHICH YOU WANT TO DELETE"<<endl;
cin>>posd;
if(head == NULL)
{
cout<<"THIS IS AN ERROR"<<endl;
}
else if(head == tail)
{
SLLNODE *temp7 = head;
delete temp7;
head = NULL;
tail = NULL;
}
else
{
SLLNODE *temp7 = head;
SLLNODE *temp8 = head;
SLLNODE *temp9 = head;
for(int i=1;i<posd;i++)
{
temp7 = temp7->next;
}
temp8 = temp7->next;
temp9 = temp8->next;
temp7->next = temp9;
temp7->next = NULL;

}
}

};
int main()
{
SLL L1;
int x = 0;

while(x!=-1)
{
cout<<endl;
cout<<"1."<<"ENTER 1 to ADD AT HEAD"<<endl;
cout<<"2."<<"ENTER 2 TO ADD AT TAIL"<<endl;
cout<<"3."<<"ENTER 3 TO SEARCH A NUMBER"<<endl;
cout<<"4."<<"ENTER 4 TO ADD A NUMBER AFTER Nth POSITION"<<endl;
cout<<"5."<<"ENTER 5 TO ADD A NUMBER BEFORE Nth POSITION"<<endl;
cout<<"6."<<"ENTER 6 TO DELETE A NUMBER FROM LINKED LIST"<<endl;
cout<<"7."<<"ENTER 7 TO DISPLAY THE NUMBERS"<<endl;
cout<<"8."<<"ENTER -1 TO EXIT"<<endl;

cin>>x;
switch(x)
{
case 1 : L1.add_at_head();
break;

case 2 : L1.add_at_tail();
break;

case 3 : L1.search();
break;
case 4 : L1.add_after_nth_position();
break;
case 5 : L1.add_before_nth_position();
break;
case 6 : L1.del();
break;
case 7 : L1.display();
break;
default : cout<<"EXIT"<<endl;
break;

}

}





// L1.add_at_nth_position(20,3);
// L1.del(2);
//L1.display();