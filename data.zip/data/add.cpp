#include<iostream>
#define MAX1 50
using namespace std;
class stack
{
    public:
    int tos;
    bool push(int el);
    int pop();
    bool is_empty();
    int array[MAX1];
    stack()
    {

        tos = -1;
    }
};
bool stack :: push(int el)
{
    if(tos<MAX)
    {
        array[++tos] = el;
        return 1;
    }
    else
    cout<<"STACK OVERFLOW"<<endl;
    return 0;
}
int stack :: pop()
{
    if(!is_empty())
     {
       int temp =  array[tos--];
       return temp;
     }
    else
       return 0;
}
bool stack :: is_empty()
{
    return(tos<0);
}
int main()
{
    stack s1;
    stack s2;
    stack s3;

    cout<<"Enter the no of elements of first number"<<endl;
    int num1;
    cin>>num1;
    cout<<"Enter the no of elements of second number"<<endl;
    int num2;
    cin>>num2;
    int temp1 = 0;
    int temp2 = 0;
    int max = 0;

    cout<<"Enter the numbers"<<endl;
    for(int i=0;i<num1;i++)
    {
        cin>>temp1;
        s1.push(temp1);
    }
    for(int i=0;i<num2;i++)
    {
        cin>>temp2;
        s2.push(temp2);
    }
    (s1>s2)?(max = s1):(max = s2);
    int carry = 0;
    int temp_digit = 0;
    int store_digit = 0;
    for(int i=0;i<max;i++)
    {
        temp_digit = s1.pop() + s2.pop() + carry ;
        store_digit = temp_digit%10;
        carry = temp_digit/10;
        s3.push(store_digit);
    }
    for(int i = 0;i<max;i++)
    {
        cout<<"THE RESULT IS"<<endl;
        cout<<s3.pop();
    }







  return 0;

}