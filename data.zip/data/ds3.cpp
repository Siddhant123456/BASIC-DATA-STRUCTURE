//PROGRAMME TO IMPLEMENT QUEUE USING ARRAYS


#include<iostream>
#define MAX 50
using namespace std;
class queue
{
  public:
  int front;
  int rear;
  queue()
  {
      front = -1;
      rear = -1;
  }
  int array[MAX];
  bool is_empty();
  bool is_full();
  bool enqueue(int el);
  int dequeue();
};
bool queue :: enqueue(int el)
{
    if(is_full())
    {
        cout<<"QUEUE IS FULL"<<endl;
        return false;
    }
    else
    {
        //int rear = -1;
        rear = rear + 1;
        array[rear] = el;
        cout<<array[rear]<<endl;
        return true;

    }
}
int queue :: dequeue()
{
    if(is_empty())
    {
        cout<<"QUEUE IS EMPTY"<<endl;
        return 0;
    }
    else
    {
        //int front = -1;
        int temp = 0;
        temp = array[front];
        front = front + 1;
        cout<<"THE ELEMENT REMOVED IS"<<"  "<<temp<<endl;
        return temp;

    }


}
bool queue :: is_empty()
{
    if(front == -1 && rear == -1)
    return true;
    else
    return false;
}
bool queue :: is_full()
{
    if(rear == MAX - 1)
    return true;
    else
    return false;
}
int main()
{
    queue q;
    q.enqueue(1);
    q.enqueue(2);
    q.enqueue(3);
    q.dequeue();

}