/*

  PROGRAMME TO PUSH AND POP NUMBERS INTO AN ARRAY

*/
#include<iostream>
using namespace std;

#define MAX 50
class stack
{
    public:
    bool push(int x);
    int pop();
    bool isEmpty();
    int tos;
    int array[MAX];
    stack()
    {
        tos = -1; //Initialze the stack
    }
};

    bool stack :: push(int x)
    {

        if(tos<MAX)
        {

            array[++tos] = x;
            cout<<endl<<array[tos]<<" "<<tos;
            return x;

        }
        else
        cout<<"STACK OVERFLOW";
        return 0;

    }

     int  stack :: pop()
    {
        if(!isEmpty())
        {
        int temp = array[tos];
        array[tos] = 0;
        tos--;
        }
        else
        return 0;

    }

    bool stack :: isEmpty()
    {
        return(tos<0);
    }

int main()
{

    stack obj;
    obj.push(1);
    obj.push(2);
    obj.push(3);
    obj.push(4);
    obj.push(5);

    return 0;

}